package groovy.tutorial

class Mammal extends Thing{
  def Mammal(name){
    this.name = name;
  }
}
