package groovy.tutorial

abstract class Thing{
  public String name;
  public Thing() {}
 
  def getInfo(){
    println("The things name is ${name}");
  }
}