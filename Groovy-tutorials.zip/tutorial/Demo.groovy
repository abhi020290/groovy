package groovy.tutorial

class Demo {

	def demoMethod() {

		// ---------- LISTS ----------
		// Lists hold a list of objects with an index

		def primes = [2, 3, 5, 7, 11, 13];

		// Get a value at an index
		println("2nd Prime " + primes[1]);
		println("3rd Prime " + primes.get(2));

		// They can hold anything
		def employee = ['Derek', 40, 6.25, [1, 2, 3]];

		println("2nd Number " + employee[3][1]);

		// Get the length
		println("Length " + primes.size());

		// Add an index
		primes.add(17);

		// Append to the right
		primes<<19;
		primes.add(23);

		// Concatenate 2 Lists
		primes + [29, 31];

		// Remove the last item
		primes - [31];

		// Check if empty
		println("Is empty " + primes.isEmpty());

		// Get 1st 3
		println("1st 3 " + primes[0..2]);

		println(primes);

		// Get matches
		println("Matches " + primes.intersect([2, 3, 7]));

		// Reverse
		println("Reverse " + primes.reverse());

		// Sorted
		println("Sorted " + primes.sort());

		// Pop last item
		println("Last " + primes.pop());

		// ---------- MAPS ----------
		// List of objects with keys versus indexes
	
			def paulMap = [
			'name' : 'Paul',
			'age' : 35,
			'address' : '123 Main St',
			'list' : [1, 2, 3]];

		// Access with key
		println("Name " + paulMap['name']);
		println("Age " + paulMap.get('age'));
		println("List Item " + paulMap['list'][1]);

		// Add key value
		paulMap.put('city', 'Pittsburgh');

		// Check for key
		println("Has City " + paulMap.containsKey('city'));

		// Size
		println("Size " + paulMap.size());

		// ---------- RANGE ----------
		// Ranges represent a range of values in shorthand notation

		def oneTo10 = 1..10;
		def aToZ = 'a'..'z';
		def zToA = 'z'..'a';

		println(oneTo10);
		println(aToZ);
		println(zToA);

		// Get size
		println("Size " + oneTo10.size());

		// get index
		println("2nd Item " + oneTo10.get(1));

		// Check if range contains
		println("Contains 11 " + oneTo10.contains(11));

		// Get last item
		println("Get Last " + oneTo10.getTo());

		println("Get First " + oneTo10.getFrom());

		// ---------- CONDITIONALS ----------
		// Conditonal Operators : ==, !=, >, <, >=, <=

		// Logical Operators : && || !

		def ageOld = 6;

		if(ageOld == 5){
			println("Go to Kindergarten");
		} else if((ageOld > 5) && (ageOld < 18)) {
			printf("Go to grade %d \n", (ageOld - 5));
		} else {
			println("Go to College");
		}

		def canVote = true;

		// Ternary operator
		println(canVote ? "Can Vote" : "Can't Vote");

		// Switch statement
		switch(ageOld) {
			case 16: println("You can drive");
			case 18:
			println("You can vote");

			// Stops checking the rest if true
			break;
			default: println("Have Fun");
		}

		// Switch with list options
		switch(ageOld){
			case 0..6 : println("Toddler"); break;
			case 7..12 : println("Child"); break;
			case 13..18 : println("Teenager"); break;
			default : println("Adult");
		}

		// ---------- LOOPING ----------
		// While loop

		def i = 0;

		while(i < 10){

			// If i is odd skip back to the beginning of the loop
			if(i % 2){
				i++;
				continue;
			}

			// If i equals 8 stop looping
			if(i == 8){
				break;
			}

			println(i);
			i++;
		}

		// Normal for loop
		for (i = 0; i < 5; i++) {
			println(i);
		}

		// for loop with a range
		for(j in 2..6){
			println(j);
		}

		// for loop with a list (Same with string)
		def randList = [10, 12, 13, 14];

		for(j in randList){
			println(j);
		}

	}

	def mapMethod(){

		// for loop with a map
		def custs = [
			100 : "Paul",
			101 : "Sally",
			102 : "Sue"
		];

		for(cust in custs){
			println("$cust.value : $cust.key ");
		}

		// ---------- METHODS ----------
		// Methods allow us to break our code into parts and also
		// allow us to reuse code

		sayHello();

		// Pass parameters
		println("5 + 4 = " + getSum(5,4));

		// Demonstrate pass by value
		def myName = "Derek";
		passByValue(myName);
		println("In Main : " + myName);

		// Pass a list for doubling
		def listToDouble = [1,2,3,4];
		listToDouble = doubleList(listToDouble);
		println(listToDouble);

		// Pass unknown number of elements to a method
		def nums = sumAll(1,2,3,4);
		println("Sum : " + nums);

		// Calculate factorial (Recursion)
		def fact4 = factorial(4);
		println("Factorial 4 : " + fact4);

		// ---------- CLOSURES ----------
		// Closures represent blocks of code that can except parameters
		// and can be passed into methods.

		// Alternative factorial using a closure
		// num is the excepted parameter and call can call for
		// the code to be executed
		def getFactorial = { num -> (num <= 1) ? 1 : num * call(num - 1) }
		println("Factorial 4 : " + getFactorial(4));

		// A closure can access values outside of it
		def greeting = "Goodbye";
		def sayGoodbye = {theName -> println("$greeting $theName")}

		sayGoodbye("Derek");

		// each performs an operation on each item in list
		def numList = [1,2,3,4];
		numList.each { println(it); }

		// Do the same with a map
		def employees = [
			'Paul' : 34,
			'Sally' : 35,
			'Sam' : 36
		];

		employees.each { println("${it.key} : ${it.value}"); }

		// Print only evens
		def randNums = [1,2,3,4,5,6];
		randNums.each {num -> if(num % 2 == 0) println(num);}

		// find returns a match
		def nameList = ['Doug', 'Sally', 'Sue'];
		def matchEle = nameList.find {item -> item == 'Sue'}
		println(matchEle);

		// findAll finds all matches
		def randNumList = [1,2,3,4,5,6];
		def numMatches = randNumList.findAll {item -> item > 4}
		println(numMatches);

		// any checks if any item matches
		println("> 5 : " + randNumList.any {item -> item > 5});

		// every checks that all items match
		println("> 1 : " + randNumList.every {item -> item > 1});

		// collect performs operations on every item
		println("Double : " + randNumList.collect { item -> item * 2});

		// pass closure to a method
		def getEven = {num -> return(num % 2 == 0)}
		def evenNums = listEdit(randNumList, getEven);
		println("Evens : " + evenNums);

		// ---------- FILE IO ----------

		// Open a file, read each line and output them
		new File("test.txt").eachLine {
			line -> println "$line";
		}

		// Overwrite the file
		new File("test.txt").withWriter('utf-8') {
			writer -> writer.writeLine("Line 4");
		}

		// Append the file
		File file = new File("test.txt");
		file.append('Line 5');

		// Get the file as a string
		println(file.text);

		// Get the file size
		println("File Size : ${file.length()} bytes");

		// Check if a file or directory
		println("File : ${file.isFile()}");
		println("Dir : ${file.isDirectory()}");

		// Copy file to another file
		def newFile = new File("test2.txt");
		newFile << file.text;

		// Delete a file
		newFile.delete();

		// Get directory files
		def dirFiles = new File("").listRoots();
		dirFiles.each {
			item -> println file.absolutePath;
		}

	}

	// ---------- METHODS ----------
	
   // Define them with def and static which means it is shared
   // by all instances of the class
   static def sayHello() {
	 println("Hello");
   }
	
   // Methods can receive parameters that have default values
   static def getSum(num1=0, num2=0){
	 return num1 + num2;
   }
	
   // Any object passed to a method is pass by value
   static def passByValue(name){
	
	 // name here is local to the function and can't
	 // be accessed outside of it
	 name = "In Function";
	 println("Name : " + name);
   }
	
   // Receive and return a list
   static def doubleList(list){
	
	 // Collect performs a calculation on every item in the list
	 def newList = list.collect { it * 2};
	 return newList;
   }
	
   // Pass unknown number of elements to a method
   static def sumAll(int... num){
	 def sum = 0;
	
	 // Performs a calculation on every item with each
	 num.each { sum += it; }
	 return sum;
   }
	
   // Calculate factorial (Recursion)
   static def factorial(num){
	 if(num <= 1){
	   return 1;
	 } else {
	   return (num * factorial(num - 1));
	 }
   }
	
   // 1st: num = 4 * factorial(3) = 4 * 6 = 24
   // 2nd: num = 3 * factorial(2) = 3 * 2 = 6
   // 3rd: num = 2 * factorial(1) = 2 * 1 = 2
	
   // ---------- CLOSURES ----------
   // pass closure to a method
	
   static def listEdit(list, clo){
	 return list.findAll(clo);
   }


}
