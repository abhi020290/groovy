package groovy.tutorial

class Widget {
 
  // Define abstract method that returns nothing
  def doSomething();
}
